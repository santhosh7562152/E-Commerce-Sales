# Project Documentation

## 1. Objective

Turn raw Superstore order data into a decision-ready dashboard that explains where the business makes and loses money, and what to do about it.

## 2. Workflow

1. **Validate** the raw CSV (`scripts/check_data.py`).
2. **Clean and prepare** in Python/Pandas (types, dates, derived columns).
3. **Analyse** with SQL (MySQL) and Python (EDA).
4. **Model and visualise** in Power BI (Power Query, DAX).
5. **Document** findings and recommendations (`INSIGHTS.md`).

## 3. Dataset

Sample Superstore: 9,994 rows, 21 columns (see `data/README.md`). Grain: one row per product line within an order.

| Group | Columns |
|---|---|
| Order | Row ID, Order ID, Order Date, Ship Date, Ship Mode |
| Customer | Customer ID, Customer Name, Segment |
| Location | Country, City, State, Postal Code, Region |
| Product | Product ID, Category, Sub-Category, Product Name |
| Measures | Sales, Quantity, Discount, Profit |

## 4. Data validation

`scripts/check_data.py` runs eight groups of checks: overview, schema, missing values, duplicates, numeric ranges, dates, categorical values and cross-column consistency. It prints PASS/WARN/FAIL lines and exits with code 1 if any check fails.

## 5. Cleaning and feature engineering (Python)

```python
import pandas as pd

df = pd.read_csv("data/superstore.csv", encoding="latin-1")
df.columns = df.columns.str.strip()
df["Order Date"] = pd.to_datetime(df["Order Date"], format="mixed")
df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="mixed")

df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.month
df["Ship Days"] = (df["Ship Date"] - df["Order Date"]).dt.days
df["Profit Margin"] = df["Profit"] / df["Sales"]
df["Discount Band"] = pd.cut(
    df["Discount"], bins=[-0.01, 0, 0.2, 0.4, 1.0],
    labels=["None", "1-20%", "21-40%", ">40%"],
)
```

## 6. KPI definitions

| KPI | Definition |
|---|---|
| Total Sales | Sum of Sales |
| Total Profit | Sum of Profit |
| Total Orders | Count of distinct Order ID |
| Profit Margin | Total Profit / Total Sales |
| Growth vs previous period | (Current - Previous) / Previous |

Note: the dashboard shows 9,994 as "Total Orders". In the standard Superstore file 9,994 is the number of **rows**, while distinct Order IDs are fewer. Confirm which definition you use and label it consistently.

## 7. SQL analysis (MySQL)

```sql
-- Monthly sales and profit
SELECT YEAR(order_date) AS yr, MONTH(order_date) AS mth,
       ROUND(SUM(sales), 2) AS sales, ROUND(SUM(profit), 2) AS profit
FROM orders
GROUP BY yr, mth
ORDER BY yr, mth;

-- Category performance
SELECT category, ROUND(SUM(sales), 2) AS sales, ROUND(SUM(profit), 2) AS profit,
       ROUND(SUM(profit) / SUM(sales) * 100, 1) AS margin_pct
FROM orders
GROUP BY category
ORDER BY profit DESC;

-- Top 5 and bottom 5 sub-categories by profit
SELECT sub_category, ROUND(SUM(profit), 2) AS profit
FROM orders GROUP BY sub_category ORDER BY profit DESC LIMIT 5;

SELECT sub_category, ROUND(SUM(profit), 2) AS profit
FROM orders GROUP BY sub_category ORDER BY profit ASC LIMIT 5;

-- Discount impact
SELECT CASE WHEN discount = 0 THEN 'None'
            WHEN discount <= 0.2 THEN '1-20%'
            WHEN discount <= 0.4 THEN '21-40%'
            ELSE '>40%' END AS discount_band,
       COUNT(*) AS lines,
       ROUND(SUM(profit) / SUM(sales) * 100, 1) AS margin_pct
FROM orders
GROUP BY discount_band;

-- Region and segment
SELECT region, ROUND(SUM(sales), 2) AS sales, ROUND(SUM(profit), 2) AS profit
FROM orders GROUP BY region ORDER BY sales DESC;

SELECT segment, ROUND(SUM(sales), 2) AS sales, ROUND(SUM(profit), 2) AS profit
FROM orders GROUP BY segment ORDER BY sales DESC;
```

## 8. Power BI model

- Single fact table (`Orders`) plus a `Date` dimension (mark as date table, relate on Order Date).
- Power Query: set data types, trim text, remove duplicates, add Ship Days.

### DAX measures

```dax
Total Sales = SUM(Orders[Sales])
Total Profit = SUM(Orders[Profit])
Total Orders = DISTINCTCOUNT(Orders[Order ID])
Profit Margin = DIVIDE([Total Profit], [Total Sales])

Sales PY = CALCULATE([Total Sales], SAMEPERIODLASTYEAR('Date'[Date]))
Sales Growth % = DIVIDE([Total Sales] - [Sales PY], [Sales PY])

Profit PY = CALCULATE([Total Profit], SAMEPERIODLASTYEAR('Date'[Date]))
Profit Growth % = DIVIDE([Total Profit] - [Profit PY], [Profit PY])

Loss-Making Lines = CALCULATE(COUNTROWS(Orders), Orders[Profit] < 0)
```

## 9. Dashboard design

| Visual | Purpose |
|---|---|
| KPI cards with sparklines | Sales, profit, orders, margin and growth |
| Combo chart | Monthly sales (bars) and profit (line) |
| Donut | Sales share by category |
| Map | Sales by region |
| Bar charts | Top 5 profit and top 5 loss-making sub-categories |
| Combo chart | Sales and profit by customer segment |
| Scatter | Discount rate vs profit margin |
| Insight and recommendation panels | Narrative summary |

Style: dark navy theme with blue, purple, green and orange accents. Date-range slicer in the header.

## 10. Known issues to check in the screenshot

- The month axis shows "Seg" instead of "Sep".
- The currency icon on the Total Sales card is a rupee symbol while values are in dollars.
- The map is a world map used for four US regions; a US map or a simple bar chart avoids confusion.
- The "Top 5 Products" panels list sub-categories; rename to "Top 5 Sub-Categories" or switch to product names.
- The standard Superstore file covers 2014-2017, so a "2021" date range suggests dates were shifted or the data differs. State this clearly.

## 11. Next steps

- Product-level and customer-level (RFM) analysis.
- Shipping-cost and delivery-time analysis by Ship Mode.
- Forecasting monthly sales.
- Publish the Power BI report and link it in the README.
