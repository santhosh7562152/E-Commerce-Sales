# Insights & Recommendations

Findings as shown on the ShopVista dashboard (period shown: 1 Jan - 31 Dec 2021).

> **Verification status:** the figures below were read from the dashboard image, not recomputed from the CSV. Tick each item in the checklist at the bottom after confirming it against your data.

## 1. Overall performance

- Total sales of **$733,215**, up **20.3%** vs the previous period (from about $609K).
- Total profit of **$93,439**, up **25.8%**.
- **9,994** orders, up 18.7%.
- Profit margin **12.7%**, up 3.5 points.
- Profit grew faster than sales, so the business became more efficient, not just bigger.
- The monthly trend is rising, with the strongest sales in October and November.

## 2. Category performance

| Category | Sales | Share of sales |
|---|---|---|
| Technology | $266,486 | 36.4% |
| Furniture | $237,243 | 32.3% |
| Office Supplies | $229,486 | 31.4% |

- Technology is the top performer: 36.4% of sales and 37.8% of profit.
- Sales are fairly evenly split, so there is no heavy dependence on one category.

## 3. Products

- **Top 5 by profit:** Phones ($30,840), Chairs ($18,693), Storage ($16,749), Binders ($12,455), Machines ($11,340).
- **Top 5 loss-makers:** Tables (-$4,893), Bookcases (-$3,721), Supplies (-$2,061), Fasteners (-$1,459), Envelopes (-$1,220).
- Note: these are sub-categories. A product-level view (Product Name) is a worthwhile follow-up.

## 4. Regions

| Region | Sales | Share |
|---|---|---|
| West | $244,057 | 33.3% |
| Central | $176,818 | 24.1% |
| East | $159,998 | 21.8% |
| South | $152,342 | 20.8% |

- West leads. South has the lowest sales but shows strong growth (+28%), which makes it the best expansion opportunity.

## 5. Customer segments

- Consumer is the largest segment by sales, followed by Corporate, then Home Office. Profit follows the same order.

## 6. Discounts

- Orders with discounts above 20% have an average margin of **-5.2%**.
- The discount vs profit-margin scatter shows a clear downward relationship: higher discount, lower margin.

## Recommendations

1. **Promote high-margin lines** (Technology, Chairs, Storage) with targeted campaigns.
2. **Review pricing and costs** for Tables, Bookcases and Supplies; consider repricing, supplier renegotiation or delisting.
3. **Cap discounts at 20%** unless a product has proven margin headroom.
4. **Invest in the South region** with regional marketing and offers.
5. **Improve supply-chain efficiency** to reduce shipping cost and lift overall margin.

## Limitations

- Correlation between discount and margin does not prove causation; product mix also matters.
- Findings are at category/sub-category level; product-level and customer-level analysis could change priorities.
- Costs other than those embedded in Profit (marketing, overheads) are not in the data.

## Verification checklist

- [ ] Total sales, profit, orders and margin match the dataset
- [ ] Category and region totals sum to total sales
- [ ] Growth percentages use the correct previous period
- [ ] Top 5 and bottom 5 lists match a sorted profit aggregation
- [ ] The -5.2% margin figure for discounts above 20% is reproducible
- [ ] The South +28% growth claim is reproducible
