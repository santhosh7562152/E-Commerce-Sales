# Data

This project uses the **Sample Superstore** dataset (9,994 order lines, 21 columns).

## Get the data

1. Download `Sample - Superstore.csv` from Kaggle (search "Superstore Dataset").
2. Save it in this folder as `superstore.csv`.
3. Validate it:

```bash
python scripts/check_data.py data/superstore.csv
```

## Columns

Row ID, Order ID, Order Date, Ship Date, Ship Mode, Customer ID, Customer Name, Segment, Country, City, State, Postal Code, Region, Product ID, Category, Sub-Category, Product Name, Sales, Quantity, Discount, Profit.

## Notes

- The Kaggle file is often `latin-1` encoded; `check_data.py` tries several encodings automatically.
- Check the licence on the Kaggle page before committing the CSV to a public repo. If unsure, keep `data/*.csv` in `.gitignore` and link to the source instead.
