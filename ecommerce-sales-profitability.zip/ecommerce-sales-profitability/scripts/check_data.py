"""
check_data.py - Inspect and validate the Superstore dataset.

Usage:
    python check_data.py                      # uses superstore.csv in current folder
    python check_data.py path/to/file.csv
    python check_data.py file.csv --save-report report.txt

Exit code: 0 if no validation errors, 1 if errors were found.
"""

import argparse
import sys
from pathlib import Path

import pandas as pd

# ----------------------------------------------------------------------------
# Expected schema (standard Superstore columns)
# ----------------------------------------------------------------------------
EXPECTED_COLUMNS = [
    "Row ID", "Order ID", "Order Date", "Ship Date", "Ship Mode",
    "Customer ID", "Customer Name", "Segment", "Country", "City", "State",
    "Postal Code", "Region", "Product ID", "Category", "Sub-Category",
    "Product Name", "Sales", "Quantity", "Discount", "Profit",
]

NUMERIC_COLUMNS = ["Sales", "Quantity", "Discount", "Profit"]
DATE_COLUMNS = ["Order Date", "Ship Date"]

VALID_VALUES = {
    "Ship Mode": {"Standard Class", "Second Class", "First Class", "Same Day"},
    "Segment": {"Consumer", "Corporate", "Home Office"},
    "Region": {"East", "West", "Central", "South"},
    "Category": {"Furniture", "Office Supplies", "Technology"},
}

KEY_COLUMNS_NO_NULLS = [
    "Order ID", "Order Date", "Ship Date", "Customer ID",
    "Product ID", "Sales", "Quantity",
]


class Report:
    """Collects messages and prints them as we go."""

    def __init__(self):
        self.lines = []
        self.errors = 0
        self.warnings = 0

    def out(self, text=""):
        print(text)
        self.lines.append(text)

    def section(self, title):
        self.out()
        self.out("=" * 70)
        self.out(title)
        self.out("=" * 70)

    def ok(self, msg):
        self.out(f"  [PASS] {msg}")

    def warn(self, msg):
        self.warnings += 1
        self.out(f"  [WARN] {msg}")

    def error(self, msg):
        self.errors += 1
        self.out(f"  [FAIL] {msg}")


def load_data(path, rep):
    """Load the CSV, trying common encodings (Superstore is often latin-1)."""
    p = Path(path)
    if not p.exists():
        rep.error(f"File not found: {p}")
        return None
    if p.stat().st_size == 0:
        rep.error(f"File is empty (0 bytes): {p}")
        return None

    for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
        try:
            df = pd.read_csv(p, encoding=enc)
            rep.ok(f"Loaded with encoding '{enc}'")
            return df
        except UnicodeDecodeError:
            continue
        except pd.errors.EmptyDataError:
            rep.error("No columns could be parsed - file has no header/data")
            return None
        except Exception as exc:  # malformed CSV etc.
            rep.error(f"Could not read file: {exc}")
            return None
    rep.error("Could not decode file with any common encoding")
    return None


def check_overview(df, rep):
    rep.section("1. OVERVIEW")
    rep.out(f"  Rows    : {len(df):,}")
    rep.out(f"  Columns : {df.shape[1]}")
    rep.out(f"  Memory  : {df.memory_usage(deep=True).sum() / 1024:.1f} KB")
    rep.out("\n  Column dtypes:")
    for col, dtype in df.dtypes.items():
        rep.out(f"    {col:<18} {dtype}")
    if len(df) == 0:
        rep.error("Dataset has headers but no rows")


def check_schema(df, rep):
    rep.section("2. SCHEMA")
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    extra = [c for c in df.columns if c not in EXPECTED_COLUMNS]
    if missing:
        rep.error(f"Missing expected columns: {missing}")
    else:
        rep.ok("All expected columns are present")
    if extra:
        rep.warn(f"Unexpected extra columns: {extra}")

    stripped = [c for c in df.columns if c != c.strip()]
    if stripped:
        rep.warn(f"Column names with leading/trailing spaces: {stripped}")


def check_missing(df, rep):
    rep.section("3. MISSING VALUES")
    nulls = df.isna().sum()
    nulls = nulls[nulls > 0]
    if nulls.empty:
        rep.ok("No missing values")
    else:
        for col, n in nulls.items():
            pct = n / len(df) * 100
            msg = f"{col}: {n:,} missing ({pct:.2f}%)"
            if col in KEY_COLUMNS_NO_NULLS:
                rep.error(msg)
            else:
                rep.warn(msg)

    # Blank / whitespace-only strings that pandas does not count as NaN
    obj_cols = df.select_dtypes(include=["object", "string"]).columns
    for col in obj_cols:
        blanks = df[col].dropna().astype(str).str.strip().eq("").sum()
        if blanks:
            rep.warn(f"{col}: {blanks:,} blank/whitespace-only values")


def check_duplicates(df, rep):
    rep.section("4. DUPLICATES")
    full = df.duplicated().sum()
    if full:
        rep.error(f"{full:,} fully duplicated rows")
    else:
        rep.ok("No fully duplicated rows")

    if "Row ID" in df.columns:
        d = df["Row ID"].duplicated().sum()
        if d:
            rep.error(f"{d:,} duplicate Row ID values (should be unique)")
        else:
            rep.ok("Row ID is unique")

    # Same order + product appearing more than once is suspicious
    if {"Order ID", "Product ID"}.issubset(df.columns):
        d = df.duplicated(subset=["Order ID", "Product ID"]).sum()
        if d:
            rep.warn(f"{d:,} repeated Order ID + Product ID combinations "
                     "(may be legitimate separate lines)")
        else:
            rep.ok("Each Order ID + Product ID is unique")


def check_numeric(df, rep):
    rep.section("5. NUMERIC COLUMNS")
    for col in NUMERIC_COLUMNS:
        if col not in df.columns:
            continue
        series = pd.to_numeric(df[col], errors="coerce")
        bad = series.isna() & df[col].notna()
        if bad.any():
            rep.error(f"{col}: {bad.sum():,} non-numeric values "
                      f"(e.g. {df.loc[bad, col].head(3).tolist()})")
            continue

        rep.out(f"\n  {col}: min={series.min():,.2f}  max={series.max():,.2f}  "
                f"mean={series.mean():,.2f}  median={series.median():,.2f}")

        if col == "Sales":
            neg = (series < 0).sum()
            zero = (series == 0).sum()
            if neg:
                rep.error(f"Sales: {neg:,} negative values")
            if zero:
                rep.warn(f"Sales: {zero:,} zero values")
        elif col == "Quantity":
            bad_q = (series <= 0).sum()
            frac = ((series % 1) != 0).sum()
            if bad_q:
                rep.error(f"Quantity: {bad_q:,} values <= 0")
            if frac:
                rep.error(f"Quantity: {frac:,} non-integer values")
        elif col == "Discount":
            out_range = ((series < 0) | (series > 1)).sum()
            if out_range:
                rep.error(f"Discount: {out_range:,} values outside 0-1")
        elif col == "Profit":
            loss = (series < 0).sum()
            rep.out(f"    Loss-making rows: {loss:,} "
                    f"({loss / max(len(df), 1) * 100:.1f}%)")

        # Outliers via IQR (informational)
        q1, q3 = series.quantile(0.25), series.quantile(0.75)
        iqr = q3 - q1
        if iqr > 0:
            outliers = ((series < q1 - 3 * iqr) | (series > q3 + 3 * iqr)).sum()
            if outliers:
                rep.warn(f"{col}: {outliers:,} extreme outliers (beyond 3x IQR)")


def check_dates(df, rep):
    rep.section("6. DATES")
    parsed = {}
    for col in DATE_COLUMNS:
        if col not in df.columns:
            continue
        s = pd.to_datetime(df[col], errors="coerce", format="mixed")
        bad = s.isna() & df[col].notna()
        if bad.any():
            rep.error(f"{col}: {bad.sum():,} unparseable dates "
                      f"(e.g. {df.loc[bad, col].head(3).tolist()})")
        else:
            rep.ok(f"{col} parses correctly "
                   f"({s.min():%Y-%m-%d} to {s.max():%Y-%m-%d})")
        parsed[col] = s

    if len(parsed) == 2:
        od, sd = parsed["Order Date"], parsed["Ship Date"]
        before = (sd < od).sum()
        if before:
            rep.error(f"{before:,} rows where Ship Date is before Order Date")
        else:
            rep.ok("Ship Date is never before Order Date")

        lag = (sd - od).dt.days.dropna()
        if len(lag):
            rep.out(f"  Shipping lag (days): min={lag.min():.0f}  "
                    f"max={lag.max():.0f}  mean={lag.mean():.1f}")
            if lag.max() > 30:
                rep.warn(f"{(lag > 30).sum():,} orders took more than 30 days to ship")

        future = (od > pd.Timestamp.today()).sum()
        if future:
            rep.warn(f"{future:,} orders dated in the future")


def check_categorical(df, rep):
    rep.section("7. CATEGORICAL VALUES")
    for col, allowed in VALID_VALUES.items():
        if col not in df.columns:
            continue
        found = set(df[col].dropna().unique())
        invalid = found - allowed
        if invalid:
            rep.error(f"{col}: unexpected values {sorted(invalid)}")
        else:
            rep.ok(f"{col}: all values valid ({len(found)} distinct)")

    for col in ["Country", "State", "City", "Sub-Category"]:
        if col in df.columns:
            rep.out(f"  {col}: {df[col].nunique()} distinct values")

    # Leading/trailing whitespace and inconsistent casing
    for col in df.select_dtypes(include=["object", "string"]).columns:
        s = df[col].dropna().astype(str)
        ws = (s != s.str.strip()).sum()
        if ws:
            rep.warn(f"{col}: {ws:,} values with leading/trailing spaces")
        if s.nunique() < 500:  # skip high-cardinality text
            lowered = s.str.strip().str.lower()
            if lowered.nunique() < s.str.strip().nunique():
                rep.warn(f"{col}: inconsistent letter casing across values")


def check_consistency(df, rep):
    rep.section("8. CONSISTENCY / RELATIONSHIPS")

    # One ID -> one name
    pairs = [
        ("Customer ID", "Customer Name"),
        ("Product ID", "Product Name"),
        ("Product ID", "Sub-Category"),
        ("Sub-Category", "Category"),
        ("Order ID", "Customer ID"),
        ("State", "Region"),
    ]
    for key, val in pairs:
        if key in df.columns and val in df.columns:
            n = df.groupby(key)[val].nunique()
            n = n[n > 1]
            if len(n):
                rep.warn(f"{len(n):,} '{key}' values map to more than one '{val}' "
                         f"(e.g. {n.index[:3].tolist()})")
            else:
                rep.ok(f"Each {key} maps to exactly one {val}")

    # Profit should not exceed sales
    if {"Sales", "Profit"}.issubset(df.columns):
        s = pd.to_numeric(df["Sales"], errors="coerce")
        p = pd.to_numeric(df["Profit"], errors="coerce")
        n = (p > s).sum()
        if n:
            rep.error(f"{n:,} rows where Profit > Sales")
        else:
            rep.ok("Profit never exceeds Sales")

    # Postal code sanity
    if "Postal Code" in df.columns:
        pc = df["Postal Code"]
        n = pc.isna().sum()
        if n:
            rep.warn(f"Postal Code: {n:,} missing "
                     "(a known gap for some Superstore versions, e.g. Burlington VT)")


def summary(rep):
    rep.section("SUMMARY")
    rep.out(f"  Errors  : {rep.errors}")
    rep.out(f"  Warnings: {rep.warnings}")
    if rep.errors == 0 and rep.warnings == 0:
        rep.out("  Result  : Dataset looks clean.")
    elif rep.errors == 0:
        rep.out("  Result  : No critical errors; review the warnings.")
    else:
        rep.out("  Result  : Critical issues found; fix before analysis.")


def main():
    parser = argparse.ArgumentParser(description="Validate the Superstore dataset.")
    parser.add_argument("path", nargs="?", default="superstore.csv",
                        help="Path to the CSV file (default: superstore.csv)")
    parser.add_argument("--save-report", metavar="FILE",
                        help="Also write the report to a text file")
    args = parser.parse_args()

    rep = Report()
    rep.section(f"SUPERSTORE DATA VALIDATION  ->  {args.path}")

    df = load_data(args.path, rep)
    if df is not None and len(df.columns) > 0:
        df.columns = df.columns.str.strip()
        check_overview(df, rep)
        check_schema(df, rep)
        check_missing(df, rep)
        check_duplicates(df, rep)
        check_numeric(df, rep)
        check_dates(df, rep)
        check_categorical(df, rep)
        check_consistency(df, rep)

    summary(rep)

    if args.save_report:
        Path(args.save_report).write_text("\n".join(rep.lines), encoding="utf-8")
        print(f"\nReport saved to {args.save_report}")

    sys.exit(1 if rep.errors else 0)


if __name__ == "__main__":
    main()
