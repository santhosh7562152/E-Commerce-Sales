# E-Commerce Sales & Profitability Dashboard

An end-to-end analytics project on the Sample Superstore dataset: validate the data, analyse sales and profitability with Python and SQL, and present the findings in a Power BI dashboard (ShopVista).

![Dashboard](images/dashboard-screenshot.png)

## Business questions

1. How are sales, profit and margin trending over time?
2. Which categories, sub-categories and products drive profit, and which lose money?
3. How do regions and customer segments compare?
4. How much do discounts hurt profitability?

## Headline results (from the dashboard)

| KPI | Value |
|---|---|
| Total Sales | $733,215 |
| Total Profit | $93,439 |
| Total Orders | 9,994 |
| Profit Margin | 12.7% |

Key findings: Technology leads on sales and profit; Tables and Bookcases lose money; orders with discounts above 20% average a negative margin. See [INSIGHTS.md](INSIGHTS.md) for details and recommendations.

> **Verify before publishing:** these figures are taken from the dashboard image. Re-run the analysis on your copy of the data and confirm every number (see the verification checklist in INSIGHTS.md).

## Tech stack

Python (Pandas, NumPy, Matplotlib, Seaborn), SQL (MySQL), Excel, Power BI (Power Query, DAX).

## Project structure

```
ecommerce-sales-profitability/
├── README.md                  Project overview
├── PROJECT_DOCUMENTATION.md   Methodology, data model, KPIs, DAX
├── INSIGHTS.md                Findings and recommendations
├── .gitignore
├── images/
│   └── dashboard-screenshot.png
├── data/
│   └── README.md              How to get the dataset
└── scripts/
    └── check_data.py          Data validation script
```

## How to run

```bash
pip install pandas
# 1. Put superstore.csv in data/ (see data/README.md)
# 2. Validate the data
python scripts/check_data.py data/superstore.csv
# 3. Load into MySQL / Power BI and build the model (see PROJECT_DOCUMENTATION.md)
```

## Dashboard pages

Overview, Sales, Profitability, Products, Customers, Regions, Discount Analysis, Reports. The overview page shows KPI cards, sales and profit trend, sales by category, sales by region, top 5 products by profit, top 5 loss-making products, segment performance, discount vs profitability, and AI-style insight and recommendation panels.

## Author

Santhosh A, final-year B.Tech CSE (AI & Data Science), Jeppiaar University.
GitHub: [santhosh7562152](https://github.com/santhosh7562152) | LinkedIn: [santhosh7562152](https://linkedin.com/in/santhosh7562152)

## Data source

Sample Superstore dataset (Kaggle).
